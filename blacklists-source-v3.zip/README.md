# DevOps

# Documentación
https://documenter.getpostman.com/view/18014154/UVyxRts9

![image](https://github.com/wilson-bg/DevOps/blob/main/screenshot/var.png)

![image](https://github.com/wilson-bg/DevOps/blob/main/screenshot/token.png)

![image](https://github.com/wilson-bg/DevOps/blob/main/screenshot/create.png)

![image](https://github.com/wilson-bg/DevOps/blob/main/screenshot/query.png)

