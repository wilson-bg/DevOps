class Config(object):
    TESTING  =  False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = f"postgresql://postgres:Amazon1234@devops.cvxrgbkdey3q.us-east-1.rds.amazonaws.com/blacklists"
